# e-commerce_Site
Designing a e-commerce_Site with the help of HTML, CSS, Bootstrap and PHP 

Tools that will be need to View and Modify this project (For Windows, MacOS and Linux)
<ul>
<li>Atom Text Editor. <a href="https://atom.io">Click here to Download</a></li>
<li>WAMP - It is an easy to install Apache distribution containing MariaDB, PHP, and Perl. <a href="http://www.wampserver.com">Click here  to dewnload WAMP</a></li>
<b>XAMPP Can also be used for this</b>
  </ul>
<ul>
  <li> Branch master has the code with HTML, CSS and Bootstrap.</li>
  <li> Branch PHP has the PHP code for different pages of this site.</li>
  </ul>
